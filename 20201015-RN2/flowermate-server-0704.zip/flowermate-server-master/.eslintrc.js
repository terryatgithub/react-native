module.exports = {
  extends: ['standard', 'prettier'],
  rules: {
    semi: ['error', 'always'],
    'no-unused-vars': 0,
  },
};
