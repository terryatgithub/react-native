module.exports = {
  singleQuote: true,
  trailingComma: 'all',
};
