module.exports = {
  debugSecret: "flowermate", // 加解密用的字符串
  prodSecret: "flowermate195433", // 加解密用的字符串
};
