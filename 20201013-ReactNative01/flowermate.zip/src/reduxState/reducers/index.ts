import dataStateReducer from './dataStateReducer';
import settingsStateReducer from './settingsStateReducer';
import uiStateReducer from './uiStateReducer';

export { uiStateReducer, dataStateReducer, settingsStateReducer };
